var searchData=
[
  ['subir_5fbicis_51',['subir_bicis',['../classCjt__estacions.html#a1c736eb41edfd04332d126fa89c9b1b4',1,'Cjt_estacions']]]
];
