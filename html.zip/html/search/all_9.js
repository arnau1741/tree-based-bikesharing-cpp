var searchData=
[
  ['pl_5flibres_46',['pl_libres',['../classCjt__estacions.html#a5bed1c677931bfdf4a3ef3f224aabf5a',1,'Cjt_estacions']]],
  ['plazas_5flibres_47',['plazas_libres',['../classCjt__estacions.html#adeffe310e34dd46d8ad0d556e9ea2a53',1,'Cjt_estacions']]],
  ['plazas_5flibres_5farbol_48',['plazas_libres_arbol',['../classCjt__estacions.html#a673aaf02aa00d0149fe3cbebc42d6d24',1,'Cjt_estacions']]],
  ['program_2ecc_49',['program.cc',['../program_8cc.html',1,'']]]
];
