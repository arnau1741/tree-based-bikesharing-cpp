var indexSectionsWithContent =
{
  0: "abcdefilmprsvw",
  1: "bce",
  2: "bcep",
  3: "abcdeflmprsvw",
  4: "bceimpv",
  5: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Páginas"
};

