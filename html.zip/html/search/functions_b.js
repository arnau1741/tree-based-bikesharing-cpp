var searchData=
[
  ['viajes_5fbici_102',['viajes_bici',['../classCjt__estacions.html#a7391ecbff4ca690cc3ccc687f9c26b1c',1,'Cjt_estacions']]]
];
