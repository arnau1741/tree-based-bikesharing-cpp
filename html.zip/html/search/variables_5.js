var searchData=
[
  ['pl_5flibres_113',['pl_libres',['../classCjt__estacions.html#a5bed1c677931bfdf4a3ef3f224aabf5a',1,'Cjt_estacions']]]
];
