var searchData=
[
  ['lectura_5festaciones_92',['lectura_estaciones',['../classCjt__estacions.html#ac27d7e92ae54afdabb1268b750f7b6ec',1,'Cjt_estacions']]],
  ['leer_5fbintree_93',['leer_BinTree',['../classCjt__estacions.html#a2549c62f700b0f24ecdfc5051b3f3b02',1,'Cjt_estacions']]]
];
