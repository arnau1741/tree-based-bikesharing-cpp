var searchData=
[
  ['plazas_5flibres_98',['plazas_libres',['../classCjt__estacions.html#adeffe310e34dd46d8ad0d556e9ea2a53',1,'Cjt_estacions']]],
  ['plazas_5flibres_5farbol_99',['plazas_libres_arbol',['../classCjt__estacions.html#a673aaf02aa00d0149fe3cbebc42d6d24',1,'Cjt_estacions']]]
];
