var searchData=
[
  ['alta_5fbici_0',['alta_bici',['../classCjt__bicis.html#af09ae87150834baca2ab995703a3b8c8',1,'Cjt_bicis::alta_bici()'],['../classCjt__estacions.html#adf1d3c2802b6e315fbfff3c96139c960',1,'Cjt_estacions::alta_bici()'],['../classEstacion.html#a244ecbd4137f8e9f50dc0b38fa4d62c5',1,'Estacion::alta_bici(Bici &amp;bici, const string &amp;origen)']]],
  ['alta_5fbici_5fsin_5fviaje_1',['alta_bici_sin_viaje',['../classEstacion.html#aaaf0a2e73c8e77cd243eb4ed3070cc82',1,'Estacion']]],
  ['anadir_5fviaje_2',['anadir_viaje',['../classBici.html#aff8bc45f77d6b90851eefa556afec50d',1,'Bici']]],
  ['asignar_5festacion_3',['asignar_estacion',['../classCjt__estacions.html#af500eda24aaaa2f02d128f06ab29d931',1,'Cjt_estacions']]]
];
